package pages.sample;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utility.TestBase_Commands;

import java.util.concurrent.TimeUnit;

public class SamplePage extends TestBase_Commands {

    private final static By tf_Username = By.xpath("//input[@name='email']");
    private final static By tf_Password = By.name("password");
    private final static By lnk_Campaign = By.xpath("//span[text()='Campaign']");
    private final static By btn_CreateCampaign = By.xpath("//span[text()=' Create Campaign ']");
    private final static By lnk_TextArea = By.xpath("//div[text()='Text Area']");
    private final static By lnk_ToLocation = By.xpath("//div[@class='ant-col ant-col-23']");
    private final static By lnk_Page1InUserFlow = By.xpath("//div[text()='Start']/following::div[@class='sc-gIBqdA eoZsQU']");
    private final static By lnk_Page1InLeftMenuUserFlow = By.xpath("//h1[text()='Pages']/following::div[@draggable='true'][1]");



    public SamplePage(WebDriver driver) {
        this.driver = driver;
    }

    // Open the application
    public void bf_OpenApplication() {

        WriteToReport("=======Start of bf_OpenApplication=============");

        // Open the browser
        Open("http://172.25.164.73:31010/signIn");


        WriteToReport("=======End of bf_OpenApplication=============");
    }

    // Open the application
    public void bf_Login() {

        WriteToReport("=======Start of bf_Login=============");


        //Type Username
        Type(tf_Username, "BuddhimaS@mitesp.com");
        //Type password
        Type(tf_Password,"mit@1234");

        WriteToReport("=======End of bf_Login=============");
    }

    // Create campaign
    public void bf_CreateCampaign() throws InterruptedException {

        WriteToReport("=======Start of bf_CreateCampaign=============");

       /* //Click Campaign
        Click(lnk_Campaign);
        //Refresh the page
        Refresh();
        //Click Create button
        Click(btn_CreateCampaign);*/
        //Enter campaign name

        Actions builder = new Actions(driver);
        WebElement from1 = driver.findElement(By.xpath("//div[text()='Components']/following::div[6]"));
        WebElement to1 = driver.findElement(By.xpath("//h4[text()='Title']/following::div[1]"));
        builder.dragAndDrop(from1, to1).build().perform();
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("function createEvent(typeOfEvent) {\n" + "var event =document.createEvent(\"CustomEvent\");\n"
                + "event.initCustomEvent(typeOfEvent,true, true, null);\n" + "event.dataTransfer = {\n" + "data: {},\n"
                + "setData: function (key, value) {\n" + "this.data[key] = value;\n" + "},\n"
                + "getData: function (key) {\n" + "return this.data[key];\n" + "}\n" + "};\n" + "return event;\n"
                + "}\n" + "\n" + "function dispatchEvent(element, event,transferData) {\n"
                + "if (transferData !== undefined) {\n" + "event.dataTransfer = transferData;\n" + "}\n"
                + "if (element.dispatchEvent) {\n" + "element.dispatchEvent(event);\n"
                + "} else if (element.fireEvent) {\n" + "element.fireEvent(\"on\" + event.type, event);\n" + "}\n"
                + "}\n" + "\n" + "function simulateHTML5DragAndDrop(element, destination) {\n"
                + "var dragStartEvent =createEvent('dragstart');\n" + "dispatchEvent(element, dragStartEvent);\n"
                + "var dropEvent = createEvent('drop');\n"
                + "dispatchEvent(destination, dropEvent,dragStartEvent.dataTransfer);\n"
                + "var dragEndEvent = createEvent('dragend');\n"
                + "dispatchEvent(element, dragEndEvent,dropEvent.dataTransfer);\n" + "}\n" + "\n"
                + "var source = arguments[0];\n" + "var destination = arguments[1];\n"
                + "simulateHTML5DragAndDrop(source,destination);", from1, to1);

        WriteToReport("=======End of bf_CreateCampaign=============");
    }
}
