package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utility.TestBase_Commands;

public class LoginPage extends TestBase_Commands {

    /** ============ Login Section ======================= **/

    private final By lbl_SignIn = By.xpath("//h2[text()='Sign In']");
    private final By lbl_SignInWithYourEmail = By.xpath("");
    private final By tf_Email = By.xpath("//input[@name='username']");
    private final By tf_Password = By.name("password");
    private final By icn_ShowPassword = By.xpath("//span[@class='ant-input-suffix']");
    private final By lbl_StayLoggedIn = By.xpath("");
    private final By chk_StayLoggedIn = By.xpath("");
    private final By lnk_ForgotPassword = By.xpath("");
    private final By btn_SignIn = By.xpath("");
    private final By icn_InvisiblePasswordProperty = By.xpath("//input[@name='password']/following::span[contains(@class,'password')]");


    /**============Login Section Validation Messages======**/

    private final By msg_RequiredEmail = By.xpath("");
    private final By msg_InvalidEmail = By.xpath("");
    private final By msg_RequiredPassword = By.xpath("");
    private final By msg_SigInErrorEnterCredentials= By.xpath("");


    /** ============ Forgot Password Section ============= **/


    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    // Open the application
    public void bf_OpenApplication() {

        WriteToReport("=======Start of bf_OpenSelfCarePortal=============");

        // Open the browser
        Open("http://172.25.164.73:31010/signIn");

        WriteToReport("=======End of bf_OpenSelfCarePortal=============");
    }

    // Verify the login UI
    public void bf_VerifyLoginUI() {

        WriteToReport("=======Start of bf_VerifyLoginUI=============");

        //Verify Sign In header
        VerifyText(lbl_SignIn,"Sign In");
        //Verify Sign In with your email sub header
        VerifyText(lbl_SignInWithYourEmail,"Sign In with your email");
        //Verify Email input field exists
        CheckElementPresent(tf_Email,true,"Email input field");
        //Verify placeholder value for email field
        VerifyPlaceHolder(tf_Email,"Email");
        //Verify Enter Password input field exists
        CheckElementPresent(tf_Password,true,"Enter Password input field");
        //Verify placeholder value for password field
        VerifyPlaceHolder(tf_Password,"Enter Password");
        //Verify show password icon exists
        CheckElementPresent(icn_ShowPassword,true,"Show Password Icon");
        //Verify Stay logged In label
        VerifyText(lbl_StayLoggedIn,"Stay logged In");
        //Verify Stay logged In checkbox exists
        CheckElementPresent(chk_StayLoggedIn,true,"Stay logged In checkbox");
        //Verify Forgot Password link
        VerifyText(lnk_ForgotPassword,"Forgot Password");
        //Verify Sign In button exists
        CheckElementPresent(btn_SignIn,true,"Sign In");
        //Verify Sign In button name
        VerifyText(btn_SignIn,"Sign In");
        //Verify Sign In button colour
        /*TBD*/

        WriteToReport("=======End of bf_VerifyLoginUI=============");
    }

    // Login to System
    public void bf_Login(String prm_Email,String prm_Password,Boolean prm_StayLoggedIn) {

        WriteToReport("=======Start of bf_Login=============");

        //Enter Email
        Type(tf_Email,prm_Email);
        //Enter Password
        Type(tf_Password,prm_Password);
        //Select Stay logged In
        if(prm_StayLoggedIn){
            Click(chk_StayLoggedIn);
        }
        //Click on Sign In button
        Click(btn_SignIn);

        WriteToReport("=======End of bf_Login=============");
    }

    // Verify the validation messages of loginUI
    public void bf_VerifyValidationMessagesOfLoginUI(String prm_Username, String prm_Password) {

        WriteToReport("=======Start of VerifyValidationMessagesOfLoginUI=============");

        //Call the login bf
        bf_Login("","",false);
        //Verify validation message once user click on Sign In without entering the email
        VerifyValidationMessage(msg_RequiredEmail, "Username is a required field ");
        //Verify validation message once user click on Sign In without entering the password
        VerifyValidationMessage(msg_RequiredPassword, "Username is a required field ");
        //Refresh the page
        Refresh();
        //Call the login bf
        bf_Login("automation_test","",false);
        //Verify validation message once user enter the invalid email
        VerifyValidationMessage(msg_InvalidEmail, "Invalid Email");
        //Refresh the page
        Refresh();
        //Call the login bf
        bf_Login("auto"+prm_Username,prm_Password,false);
        //Verify validation message once user enter incorrect email & correct password
        VerifyValidationMessage(msg_SigInErrorEnterCredentials, "SignIn Error - Enter Correct Credentials to get Sign In");
        //Refresh the page
        Refresh();
        //Call the login bf
        bf_Login(prm_Username,prm_Password+"auto",false);
        //Verify validation message once user enter correct email & incorrect password
        VerifyValidationMessage(msg_SigInErrorEnterCredentials, "SignIn Error - Enter Correct Credentials to get Sign In");

        WriteToReport("=======End of VerifyValidationMessagesOfLoginUI=============");
    }

    // Verify that password visible or not when clicking on icon
    public void bf_VerifyPasswordIsVisible() {

        WriteToReport("=======Start of bf_VerifyPasswordIsVisible=============");

        //Enter Password
        String password="123456";
        Type(tf_Password,password);
        //Click on show password icon
        Click(icn_ShowPassword);
        //Store visible password after click on the show password icon
        String VisiblePassword=StoreValue(tf_Password);
        //Verify that Password is correct
        if(password.equalsIgnoreCase(VisiblePassword))
        {
            WritePassMessageToReport("Password is correctly visible to the user as "+VisiblePassword);
        }
        else{
            FailTest("Password is not visible to the user.Expected "+password+" ,but found "+VisiblePassword);
        }
        //Again click on show password icon
        Click(icn_ShowPassword);
        //Store class property value
        String ElementProperty=StoreProperty(icn_InvisiblePasswordProperty,"class");
        //Verify class property contains the eye-invisible ant-input-password-icon
        if (ElementProperty.contains("invisible"))
        {
            WritePassMessageToReport("Password is correctly visible to the user in password mode as ......");
        }
        else
        {
            FailTest("Password is visible to the user as "+VisiblePassword);
        }

        WriteToReport("=======End of bf_VerifyPasswordIsVisible=============");
    }


    // Click on forgot password Link
    public void bf_ClickForgotPassword() {

        WriteToReport("=======Start of bf_ClickForgotPassword=============");

        //Click on Forgot Password link
        Click(lnk_ForgotPassword);

        WriteToReport("=======End of bf_ClickForgotPassword=============");
    }

}
