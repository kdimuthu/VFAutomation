package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utility.TestBase_Commands;

public class CreateViewAndEditCampaignPage extends TestBase_Commands {

    /** ============ Header Section ============================================= **/

    private final By lbl_CreateCampaignHeader = By.xpath("");


    /** ============ General tab Section ======================= **/
    
    /** ============ Page Designer / Components Section ======== **/

    /** ============ Page Designer / General tab Section ======= **/

    /** ============ Page Designer / Validation tab Section ==== **/

    /** ============ Page Designer / Language tab Section ====== **/

    /** ============ Page Designer / Advanced tab Section ====== **/

    /** ============ Page Designer / Question Bank Section ====  **/

    /** ============ User Flow tab Section ===================== **/

    /** ============ Reviewer Flow / Pages Section ============= **/

    /** ============ Reviewer Flow / Controls Section ========== **/




    public CreateViewAndEditCampaignPage(WebDriver driver) {
        this.driver = driver;
    }

    // Verify the General Tab UI
    public void bf_VerifyGeneralTabUI() {

        WriteToReport("=======Start of bf_VerifyGeneralTabUI=============");


        WriteToReport("=======End of bf_VerifyGeneralTabUI===============");
    }

    // Verify the validation massages of general UI
    public void bf_VerifyValidationMessagesOfGeneralTabUI() {

        WriteToReport("=======Start of bf_VerifyValidationMessagesOfGeneralTabUI=============");


        WriteToReport("=======End of bf_VerifyValidationMessagesOfGeneralTabUI===============");
    }

    // Click Back icon near Heading
    public void bf_ClickBackIcon() {

        WriteToReport("=======Start of bf_ClickBackIcon=============");


        WriteToReport("=======End of bf_ClickBackIcon===============");
    }

    // Click View All button in Revision History section
    public void bf_ClickViewAllFromVersionHistory() {

        WriteToReport("=======Start of bf_ClickBackIcon=============");


        WriteToReport("=======End of bf_ClickBackIcon===============");
    }

    // Verify revision history once user clicked on View All button
    public void bf_VerifyVersionHistoryAfterClickingViewAll() {

        WriteToReport("=======Start of bf_VerifyVersionHistoryAfterClickingViewAll=============");


        WriteToReport("=======End of bf_VerifyVersionHistoryAfterClickingViewAll===============");
    }

    // Enter details in General tab section & Store the information
    public String[] bf_EnterAndStoreGeneralTabInformation() {

        WriteToReport("=======Start of bf_VerifyVersionHistoryAfterClickingViewAll=============");

        String[] GeneralInformation = new String[10];

        WriteToReport("=======End of bf_VerifyVersionHistoryAfterClickingViewAll===============");
        return GeneralInformation;
    }

    // Click Prev Steps button or Next Step button
    public void bf_ClickPrevStepOrNextStep() {

        WriteToReport("=======Start of bf_ClickPrevStepOrNextStep=============");


        WriteToReport("=======End of bf_ClickPrevStepOrNextStep===============");
    }

    // Move between tabs General, Page Designer, User Flow and Reviewer Flow
    public void bf_MoveToTabs() {

        WriteToReport("=======Start of bf_MoveToTabs=============");


        WriteToReport("=======End of bf_MoveToTabs===============");
    }

    // Refresh the page
    public void bf_RefreshPage() {

        WriteToReport("=======Start of bf_RefreshPage=============");


        WriteToReport("=======End of bf_RefreshPage===============");
    }

    // Verify the information is correct in General Tab after refreshing, navigating using Prev Steps etc...
    public void bf_VerifyTheInformationInGeneralTab() {

        WriteToReport("=======Start of bf_VerifyTheInformationInGeneralTab=============");


        WriteToReport("=======End of bf_VerifyTheInformationInGeneralTab===============");
    }

    // Verify the Page Designer Tab UI
    public void bf_VerifyPageDesignerTabUI() {

        WriteToReport("=======Start of bf_VerifyPageDesignerTabUI=============");


        WriteToReport("=======End of bf_VerifyPageDesignerTabUI===============");
    }

    // Click on Components or Question Bank links
    public void bf_ClickComponentsOrQuestionBankLink() {

        WriteToReport("=======Start of bf_ClickComponentsOrQuestionBankLink=============");


        WriteToReport("=======End of bf_ClickComponentsOrQuestionBankLink===============");
    }

    // Verify the UI after clicking on Question Bank link
    public void bf_VerifyUIAfterClickingQuestionBankLink() {

        WriteToReport("=======Start of bf_ClickComponentsOrQuestionBankLink=============");


        WriteToReport("=======End of bf_ClickComponentsOrQuestionBankLink===============");
    }

    // Perform a search in Search for components search field
    public void bf_SearchUsingSearchForComponents() {

        WriteToReport("=======Start of bf_SearchUsingSearchForComponents=============");


        WriteToReport("=======End of bf_SearchUsingSearchForComponents===============");
    }

    // Verify the search results after searching using Search for components
    public void bf_VerifySearchResultsForComponents() {

        WriteToReport("=======Start of bf_VerifySearchResultsForComponents=============");


        WriteToReport("=======End of bf_VerifySearchResultsForComponents===============");
    }

    // Clear the search name in Search for components field after searching
    public void bf_ClearSearchForComponentsFiled() {

        WriteToReport("=======Start of bf_ClearSearchForComponentsFiled=============");


        WriteToReport("=======End of bf_ClearSearchForComponentsFiled===============");
    }

    // Click on < icon or > icon. This is common for all icons in all tabs
    public void bf_ClickLeftOrRightArrowIcon() {

        WriteToReport("=======Start of bf_ClickLeftOrRightArrowIcon=============");


        WriteToReport("=======End of bf_ClickLeftOrRightArrowIcon===============");
    }

    // Verify the left menu after clicking on < icon in Page Designer tab
    public void bf_VerifyLeftMenuInPageDesignerTabAfterClickLeftIcon() {

        WriteToReport("=======Start of bf_VerifyLeftMenuInPageDesignerTabAfterClickLeftIcon=============");


        WriteToReport("=======End of bf_VerifyLeftMenuInPageDesignerTabAfterClickLeftIcon===============");
    }

    // Verify the right menu after clicking on > icon in Page Designer tab
    public void bf_VerifyRightMenuInPageDesignerTabAfterClickRightIcon() {

        WriteToReport("=======Start of bf_VerifyRightMenuInPageDesignerTabAfterClickRightIcon=============");


        WriteToReport("=======End of bf_VerifyRightMenuInPageDesignerTabAfterClickRightIcon===============");
    }

    // Click on (+) Add pages
    public void bf_AddPages() {

        WriteToReport("=======Start of bf_AddPages=============");


        WriteToReport("=======End of bf_AddPages===============");
    }

    // Verify the right menu after adding a new page
    public void bf_VerifyRightMenuAfterAddingAPage() {

        WriteToReport("=======Start of bf_VerifyRightMenuAfterAddingAPage=============");


        WriteToReport("=======End of bf_VerifyRightMenuAfterAddingAPage===============");
    }

    // Verify the select page dropdown after adding a new page
    public void bf_VerifySelectPagesDropdownAfterAddingAPage() {

        WriteToReport("=======Start of bf_VerifySelectPagesDropdownAfterAddingAPage=============");


        WriteToReport("=======End of bf_VerifySelectPagesDropdownAfterAddingAPage===============");
    }

    // Verify the page grid after adding a new page
    public void bf_VerifyGridAfterAddingAPage() {

        WriteToReport("=======Start of bf_VerifyGridAfterAddingAPage=============");


        WriteToReport("=======End of bf_VerifyGridAfterAddingAPage===============");
    }

    // Select a page from Select Page dropdown
    public void bf_SelectAPageFromSelectPageDropdown() {

        WriteToReport("=======Start of bf_SelectAPageFromSelectPageDropdown=============");


        WriteToReport("=======End of bf_SelectAPageFromSelectPageDropdown===============");
    }

    // Select a page from Select Page dropdown
    public void bf_VerifySuccessMessage() {

        WriteToReport("=======Start of bf_VerifySuccessMessage=============");


        WriteToReport("=======End of bf_VerifySuccessMessage===============");
    }

    // Select a columns from number of columns drop down
    public void bf_SelectAColumn() {

        WriteToReport("=======Start of bf_SelectAColumn=============");


        WriteToReport("=======End of bf_SelectAColumn===============");
    }

    // Verify the grid after selecting a column with different settings from number of column dropdown
    public void bf_VerifyGridAfterSelectingAColumn() {

        WriteToReport("=======Start of bf_VerifyGridAfterSelectingAColumn=============");


        WriteToReport("=======End of bf_VerifyGridAfterSelectingAColumn===============");
    }

    // Select a Language right menu once page is added
    public void bf_SelectALanguageFromRightMenuOncePageIsAdded() {

        WriteToReport("=======Start of bf_SelectALanguageFromRightMenuOncePageIsAdded=============");


        WriteToReport("=======End of bf_SelectALanguageFromRightMenuOncePageIsAdded===============");
    }

    // Verify the right menu after selecting a new language
    public void bf_VerifyRightMenuAfterSelectingALanguage() {

        WriteToReport("=======Start of bf_VerifyRightMenuAfterSelectingALanguage=============");


        WriteToReport("=======End of bf_VerifyRightMenuAfterSelectingALanguage===============");
    }

    // Enter a page title and page description
    public void bf_EnterAPageNameAndADescription() {

        WriteToReport("=======Start of bf_EnterAPageNameAndADescription=============");


        WriteToReport("=======End of bf_EnterAPageNameAndADescription===============");
    }

    // Verify the page grid after entering a page tile or description in right menu
    public void bf_VerifyGridAfterEnteringPageTitleAndDescription() {

        WriteToReport("=======Start of bf_VerifyGridAfterEnteringPageTitleAndDescription=============");


        WriteToReport("=======End of bf_VerifyGridAfterEnteringPageTitleAndDescription===============");
    }

    // Delete a page
    public void bf_DeleteAPage() {

        WriteToReport("=======Start of bf_DeleteAPage=============");


        WriteToReport("=======End of bf_DeleteAPage===============");
    }

    // Verify the right menu after deleting a page
    public void bf_VerifyRightMenuAfterDeletingAPage() {

        WriteToReport("=======Start of bf_VerifyRightMenuAfterDeletingAPage=============");


        WriteToReport("=======End of bf_VerifyRightMenuAfterDeletingAPage===============");
    }

    // Verify the select page dropdown after deleting a page
    public void bf_VerifySelectPageDropdownAfterDeletingAPage() {

        WriteToReport("=======Start of bf_VerifySelectPageDropdownAfterDeletingAPage=============");


        WriteToReport("=======End of bf_VerifySelectPageDropdownAfterDeletingAPage===============");
    }

    // Verify the grid after deleting a page
    public void bf_VerifyGridAfterDeletingAPage() {

        WriteToReport("=======Start of bf_VerifyGridAfterDeletingAPage=============");


        WriteToReport("=======End of bf_VerifyGridAfterDeletingAPage===============");
    }

    // Add a component to a page
    public void bf_AddAComponentToPage() {

        WriteToReport("=======Start of bf_AddAComponentToPage=============");


        WriteToReport("=======End of bf_AddAComponentToPage===============");
    }

    // Verify the General tab UI for added component
    public void bf_VerifyGeneralTabForAddedComponent() {

        WriteToReport("=======Start of bf_VerifyGeneralTabForAddedComponent=============");


        WriteToReport("=======End of bf_VerifyGeneralTabForAddedComponent===============");
    }

    // Verify the Validation tab UI for added component
    public void bf_VerifyValidationTabForAddedComponent() {

        WriteToReport("=======Start of bf_VerifyValidationTabForAddedComponent=============");


        WriteToReport("=======End of bf_VerifyValidationTabForAddedComponent===============");
    }

    // Verify the Language tab UI for added component
    public void bf_VerifyLanguageTabForAddedComponent() {

        WriteToReport("=======Start of bf_VerifyLanguageTabForAddedComponent=============");


        WriteToReport("=======End of bf_VerifyLanguageTabForAddedComponent===============");
    }

    // Verify the Advanced tab UI for added component
    public void bf_VerifyAdvancedTabForAddedComponent() {

        WriteToReport("=======Start of bf_VerifyAdvancedTabForAddedComponent=============");


        WriteToReport("=======End of bf_VerifyAdvancedTabForAddedComponent===============");
    }

    // Move between tabs General, Validation, Language and Advanced
    public void bf_MoveToTabsForAddedComponent() {

        WriteToReport("=======Start of bf_MoveToTabsForAddedComponent=============");


        WriteToReport("=======End of bf_MoveToTabsForAddedComponent===============");
    }

    // Enter a title for question & Store
    public String bf_ChangeQuestionTitleAndStore() {

        WriteToReport("=======Start of bf_ChangeQuestionTitleAndStore=============");

        String title="";


        WriteToReport("=======End of bf_ChangeQuestionTitleAndStore===============");

        return title;
    }

    // Verify the title in grid after changing the title of the question
    public void bf_VerifyTitleInGridAfterChangingTitle() {

        WriteToReport("=======Start of bf_VerifyTitleInGridAfterChangingTitle=============");


        WriteToReport("=======End of bf_VerifyTitleInGridAfterChangingTitle===============");
    }

    // Enter component details & Store
    public String[] bf_AddAndStoreComponentDetails() {

        WriteToReport("=======Start of bf_AddAndStoreComponentDetails=============");

        String[] QuestionInformation = new String[10];

        WriteToReport("=======End of bf_AddAndStoreComponentDetails===============");
        return QuestionInformation;
    }

    // Click Delete Component button for added questions
    public void bf_ClickDeleteComponent() {

        WriteToReport("=======Start of bf_ClickDeleteComponent=============");


        WriteToReport("=======End of bf_ClickDeleteComponent===============");
    }

    // Verify the grid after deleting a question
    public void bf_VerifyGridAfterDeletingAComponent() {

        WriteToReport("=======Start of bf_VerifyGridAfterDeletingAComponent=============");


        WriteToReport("=======End of bf_VerifyGridAfterDeletingAComponent===============");
    }

    // Verify the Right menu after deleting a question
    public void bf_VerifyRightMenuAfterDeletingAComponent() {

        WriteToReport("=======Start of bf_VerifyRightMenuAfterDeletingAComponent=============");


        WriteToReport("=======End of bf_VerifyRightMenuAfterDeletingAComponent===============");
    }

    // Verify the Question Bank menu in left side after saving a new question using Save To Question Bank
    public void bf_VerifyQuestionBankMenuAfterClickingSaveToQuestionBank() {

        WriteToReport("=======Start of bf_VerifyQuestionBankMenuAfterClickingSaveToQuestionBank=============");


        WriteToReport("=======End of bf_VerifyQuestionBankMenuAfterClickingSaveToQuestionBank===============");
    }

    //Perform a search in Search for questions in Question Bank UI
    public void bf_SearchUsingSearchForQuestions() {

        WriteToReport("=======Start of bf_SearchUsingSearchForQuestions=============");


        WriteToReport("=======End of bf_SearchUsingSearchForQuestions===============");
    }

    //Verify the search results after searching in Search for questions in Question Bank UI
    public void bf_VerifySearchResultsForQuestionsInQuestionBank() {

        WriteToReport("=======Start of bf_VerifySearchResultsForQuestionsInQuestionBank=============");


        WriteToReport("=======End of bf_VerifySearchResultsForQuestionsInQuestionBank===============");
    }

    //Clear the searched item name in Search for questions in Question Bank UI
    public void bf_ClearSearchForQuestionSearchField() {

        WriteToReport("=======Start of bf_ClearSearchForQuestionSearchField=============");


        WriteToReport("=======End of bf_ClearSearchForQuestionSearchField===============");
    }

    //Click plus mark (+) in Question Bank UI
    public void bf_ClickPlusMarkFromQuestionMark() {

        WriteToReport("=======Start of bf_ClickPlusMarkFromQuestionMark=============");


        WriteToReport("=======End of bf_ClickPlusMarkFromQuestionMark===============");
    }

    //Verify the window opening after clicking on plus mark (+) in Question Bank UI
    public void bf_VerifyWindowOpenedAfterClickingPlusMarkFromQuestionBank() {

        WriteToReport("=======Start of bf_VerifyWindowOpenedAfterClickingPlusMarkFromQuestionBank=============");


        WriteToReport("=======End of bf_VerifyWindowOpenedAfterClickingPlusMarkFromQuestionBank===============");
    }

    //Close the window opening after clicking on plus mark (+) in Question Bank UI
    public void bf_CloseWindowOpenedAfterClickingPlusMarkFromQuestionBank() {

        WriteToReport("=======Start of bf_CloseWindowOpenedAfterClickingPlusMarkFromQuestionBank=============");


        WriteToReport("=======End of bf_CloseWindowOpenedAfterClickingPlusMarkFromQuestionBank===============");
    }

    //Add a new component from the window opening after clicking on plus mark (+) in Question Bank UI
    public void bf_AddANewComponentFromWindowOpenedAfterClickingPlusMarkFromQuestionBank() {

        WriteToReport("=======Start of bf_AddANewComponentFromWindowOpenedAfterClickingPlusMarkFromQuestionBank=============");


        WriteToReport("=======End of bf_AddANewComponentFromWindowOpenedAfterClickingPlusMarkFromQuestionBank===============");
    }

    //Verify the validation message of Page Designer UI
    public void bf_VerifyValidationMessagesOfPageDesignerTab() {

        WriteToReport("=======Start of bf_VerifyValidationMessagesOfPageDesignerTab=============");


        WriteToReport("=======End of bf_VerifyValidationMessagesOfPageDesignerTab===============");
    }

    //Verify the left menu in User Flow after clicking on < icon
    public void bf_VerifyLeftMenuInUserFlowTabAfterClickLeftIcon() {

        WriteToReport("=======Start of bf_VerifyLeftMenuInUserFlowTabAfterClickLeftIcon=============");


        WriteToReport("=======End of bf_VerifyLeftMenuInUserFlowTabAfterClickLeftIcon===============");
    }

    //Verify the User Flow UI
    public void bf_VerifyUserFlowUI() {

        WriteToReport("=======Start of bf_VerifyUserFlowUI=============");


        WriteToReport("=======End of bf_VerifyUserFlowUI===============");
    }

    //Verify the right menu in User Flow after clicking on > icon
    public void bf_VerifyRightMenuInUserFlowTabAfterClickRightIcon() {

        WriteToReport("=======Start of bf_VerifyRightMenuInUserFlowTabAfterClickRightIcon=============");


        WriteToReport("=======End of bf_VerifyRightMenuInUserFlowTabAfterClickRightIcon===============");
    }

    //Verify the right menu in User Flow after clicking on > icon
    public void bf_VerifyRightMenuInUserFlowTabAfterClickLeftIcon() {

        WriteToReport("=======Start of bf_VerifyRightMenuInUserFlowTabAfterClickLeftIcon=============");


        WriteToReport("=======End of bf_VerifyRightMenuInUserFlowTabAfterClickLeftIcon===============");
    }

    //Verify that added pages and questions in page designer tab is correct in User Flow
    public void bf_VerifyAddedPagesAndQuestionsInLeftMenuOfUserFlow() {

        WriteToReport("=======Start of bf_VerifyAddedPagesAndQuestionsInLeftMenuOfUserFlow=============");


        WriteToReport("=======End of bf_VerifyAddedPagesAndQuestionsInLeftMenuOfUserFlow===============");
    }

    //Add a page to User Flow (drag and drop)
    public void bf_AddAPageToUserFlow() {

        WriteToReport("=======Start of bf_AddAPageToUserFlow=============");


        WriteToReport("=======End of bf_AddAPageToUserFlow===============");
    }

    //Verify the grid after adding a page to user flow
    public void bf_VerifyGridAfterAddingAPageToUserFlow() {

        WriteToReport("=======Start of bf_VerifyGridAfterAddingAPageToUserFlow=============");


        WriteToReport("=======End of bf_VerifyGridAfterAddingAPageToUserFlow===============");
    }

    //Remove the added page from user flow
    public void bf_RemoveTheAddedPageFromUserFlow() {

        WriteToReport("=======Start of bf_RemoveTheAddedPageFromUserFlow=============");


        WriteToReport("=======End of bf_RemoveTheAddedPageFromUserFlow===============");
    }

    //Remove the added page from user flow
    public void bf_VerifyGridAfterRemovingTheAddedPageFromUserFlow() {

        WriteToReport("=======Start of bf_VerifyGridAfterRemovingTheAddedPageFromUserFlow=============");


        WriteToReport("=======End of bf_VerifyGridAfterRemovingTheAddedPageFromUserFlow===============");
    }

    //Change the added page from user flow
    public void bf_ChangeTheAddedPageFromUserFlow() {

        WriteToReport("=======Start of bf_ChangeTheAddedPageFromUserFlow=============");


        WriteToReport("=======End of bf_ChangeTheAddedPageFromUserFlow===============");
    }

    //Change the added page from user flow
    public void bf_VerifyGridAfterChangingTheAddedPageFromUserFlow() {

        WriteToReport("=======Start of bf_VerifyGridAfterChangingTheAddedPageFromUserFlow=============");


        WriteToReport("=======End of bf_VerifyGridAfterChangingTheAddedPageFromUserFlow===============");
    }

    //Verify the validation messages of User Flow UI
    public void bf_VerifyValidationMessagesOfUserFlow() {

        WriteToReport("=======Start of bf_VerifyValidationMessagesOfUserFlow=============");


        WriteToReport("=======End of bf_VerifyValidationMessagesOfUserFlow===============");
    }

    //Verify the Reviewer Flow UI
    public void bf_VerifyReviewerFlowUI() {

        WriteToReport("=======Start of bf_VerifyReviewerFlowUI=============");


        WriteToReport("=======End of bf_VerifyReviewerFlowUI===============");
    }

    //Verify that added pages in page designer tab is available in Reviewer Flow with correct names
    public void bf_VerifyAddedPagesInLeftMenuInReviewerFlow() {

        WriteToReport("=======Start of bf_VerifyAddedPagesInLeftMenuInReviewerFlow=============");


        WriteToReport("=======End of bf_VerifyAddedPagesInLeftMenuInReviewerFlow===============");
    }

    //Click on expand icon in left menu & expand the page
    public void bf_ClickOnExpandIconOfPageNameInLeftMenu() {

        WriteToReport("=======Start of bf_ClickOnExpandIconOfPageNameInLeftMenu=============");


        WriteToReport("=======End of bf_ClickOnExpandIconOfPageNameInLeftMenu===============");
    }

    //Verify that added question list is showing correctly with correct names after expanding the page
    public void bf_VerifyAddedQuestionNames() {

        WriteToReport("=======Start of bf_VerifyAddedQuestionNames=============");


        WriteToReport("=======End of bf_VerifyAddedQuestionNames===============");
    }

    //Perform a search using Search for pages
    public void bf_SearchUsingSearchForPages() {

        WriteToReport("=======Start of bf_SearchUsingSearchForPages=============");


        WriteToReport("=======End of bf_SearchUsingSearchForPages===============");
    }

    //Verify the search result after search using Search for pages
    public void bf_VerifySearchResultsOfSearchForPagesSearch() {

        WriteToReport("=======Start of bf_VerifySearchResultsOfSearchForPagesSearch=============");


        WriteToReport("=======End of bf_VerifySearchResultsOfSearchForPagesSearch===============");
    }

    //Clear the search item name in Search for pages search field
    public void bf_ClearSearchForPagesSearchField() {

        WriteToReport("=======Start of bf_ClearSearchForPagesSearchField=============");


        WriteToReport("=======End of bf_ClearSearchForPagesSearchField===============");
    }

    //Click and Add a Flow
    public void bf_AddAFlow() {

        WriteToReport("=======Start of bf_AddAFlow=============");


        WriteToReport("=======End of bf_AddAFlow===============");
    }

    //Verify the Flow dropdown after adding a new flow
    public void bf_VerifyFlowDropDownAfterAddingANewFlow() {

        WriteToReport("=======Start of bf_VerifyFlowDropDownAfterAddingANewFlow=============");


        WriteToReport("=======End of bf_VerifyFlowDropDownAfterAddingANewFlow===============");
    }

    //Click on Pages or Controls link from Reviewer Flow
    public void bf_ClickControlsOrPagesLink() {

        WriteToReport("=======Start of bf_ClickControlsOrPagesLink=============");


        WriteToReport("=======End of bf_ClickControlsOrPagesLink===============");
    }

    //Verify the left menu in Reviewer Flow UI once user click Controls UI
    public void bf_VerifyLeftMenuInReviewerFlowOnceClickedOnControlsLink() {

        WriteToReport("=======Start of bf_VerifyLeftMenuInReviewerFlowOnceClickedOnControlsLink=============");


        WriteToReport("=======End of bf_VerifyLeftMenuInReviewerFlowOnceClickedOnControlsLink===============");
    }

    //Verify the right menu in Reviewer Flow UI once user click Controls UI
    public void bf_VerifyRightMenuInReviewerFlowOnceClickedOnControlsLink() {

        WriteToReport("=======Start of bf_VerifyRightMenuInReviewerFlowOnceClickedOnControlsLink=============");


        WriteToReport("=======End of bf_VerifyRightMenuInReviewerFlowOnceClickedOnControlsLink===============");
    }

    //Verify the validations messages when adding reviewers to Flow without adding an operations
    public void bf_VerifyValidationMessageWhenAddingReviewerToAFlowWithoutAddingOperations() {

        WriteToReport("=======Start of bf_VerifyValidationMessageWhenAddingReviewerToAFlowWithoutAddingOperations=============");


        WriteToReport("=======End of bf_VerifyValidationMessageWhenAddingReviewerToAFlowWithoutAddingOperations===============");
    }

    //Add operations to Flow
    public void bf_AddAnOperationToFlow() {

        WriteToReport("=======Start of bf_AddAnOperationToFlow=============");


        WriteToReport("=======End of bf_AddAnOperationToFlow===============");
    }

    //Verify the gird after adding an operation to Reviewer Flow
    public void bf_VerifyGridAfterAddingAnOperation() {

        WriteToReport("=======Start of bf_VerifyGridAfterAddingAnOperation=============");


        WriteToReport("=======End of bf_VerifyGridAfterAddingAnOperation===============");
    }

    //Verify the right menu after adding an operation to Reviewer Flow
    public void bf_VerifyRightMenuAfterAddingAnOperation() {

        WriteToReport("=======Start of bf_VerifyRightMenuAfterAddingAnOperation=============");


        WriteToReport("=======End of bf_VerifyRightMenuAfterAddingAnOperation===============");
    }

    //Change the added operation
    public void bf_ChangingTheAddedOperation() {

        WriteToReport("=======Start of bf_ChangingTheAddedOperation=============");


        WriteToReport("=======End of bf_ChangingTheAddedOperation===============");
    }

    //Verify the grid after changing the added operation
    public void bf_VerifyGirdAfterChangingAnOperation() {

        WriteToReport("=======Start of bf_VerifyGirdAfterChangingAnOperation=============");


        WriteToReport("=======End of bf_VerifyGirdAfterChangingAnOperation===============");
    }

    //Verify the right menu after changing the added operation
    public void bf_VerifyRightMenuAfterChangingAnOperation() {

        WriteToReport("=======Start of bf_VerifyRightMenuAfterChangingAnOperation=============");


        WriteToReport("=======End of bf_VerifyRightMenuAfterChangingAnOperation===============");
    }

    //Remove the added operations
    public void bf_RemoveTheAddedOperation() {

        WriteToReport("=======Start of bf_RemoveTheAddedOperation=============");


        WriteToReport("=======End of bf_RemoveTheAddedOperation===============");
    }

    //Verify the grid after removing the added operations
    public void bf_VerifyGirdAfterRemovingAnOperation() {

        WriteToReport("=======Start of bf_VerifyGirdAfterRemovingAnOperation=============");


        WriteToReport("=======End of bf_VerifyGirdAfterRemovingAnOperation===============");
    }

    //Verify the right menu after removing the added operations
    public void bf_VerifyRightMenuAfterRemovingAnOperation() {

        WriteToReport("=======Start of bf_VerifyRightMenuAfterRemovingAnOperation=============");


        WriteToReport("=======End of bf_VerifyRightMenuAfterRemovingAnOperation===============");
    }

    //Add reviewers to an operations
    public void bf_AddReviewerToAnOperation() {

        WriteToReport("=======Start of bf_AddReviewerToAnOperation=============");


        WriteToReport("=======End of bf_AddReviewerToAnOperation===============");
    }

    //Remove a reviewer from an operations
    public void bf_RemoveAReviewerFromAnOperation() {

        WriteToReport("=======Start of bf_RemoveAReviewerFromAnOperation=============");


        WriteToReport("=======End of bf_RemoveAReviewerFromAnOperation===============");
    }

    //Verify the left menu in Reviewer Flow after clicking on Left Icon
    public void bf_VerifyLeftMenuInReviewerFlowTabAfterClickLeftIcon() {

        WriteToReport("=======Start of bf_VerifyLeftMenuInReviewerFlowTabAfterClickLeftIcon=============");


        WriteToReport("=======End of bf_VerifyLeftMenuInReviewerFlowTabAfterClickLeftIcon===============");
    }

    //Verify the right menu in Reviewer Flow after clicking on right Icon
    public void bf_VerifyRightMenuInReviewerFlowTabAfterClickRightIcon() {

        WriteToReport("=======Start of bf_VerifyRightMenuInReviewerFlowTabAfterClickRightIcon=============");


        WriteToReport("=======End of bf_VerifyRightMenuInReviewerFlowTabAfterClickRightIcon===============");
    }

    //Click Save button
    public void bf_ClickSave() {

        WriteToReport("=======Start of bf_ClickSave=============");


        WriteToReport("=======End of bf_ClickSave===============");
    }

    //Click Discard button
    public void bf_ClickDiscard() {

        WriteToReport("=======Start of bf_ClickDiscard=============");


        WriteToReport("=======End of bf_ClickDiscard===============");
    }

    //Click Preview button

    public void bf_ClickPreview() {

        WriteToReport("=======Start of bf_ClickPreview=============");


        WriteToReport("=======End of bf_ClickPreview===============");
    }

    //Verify the validation messages of Reviewers Flow UI
    public void bf_VerifyValidationMessagesOfReviewerFlowUI() {

        WriteToReport("=======Start of bf_VerifyValidationMessagesOfReviewerFlowUI=============");


        WriteToReport("=======End of bf_VerifyValidationMessagesOfReviewerFlowUI===============");
    }

    //Click one of Preview icons for Mobile, Desktop and Tablets
    public void bf_ClickPreviewIcon() {

        WriteToReport("=======Start of bf_ClickPreviewIcon=============");


        WriteToReport("=======End of bf_ClickPreviewIcon===============");
    }

    //Verify after clicking on Preview icons
    public void bf_VerifyAfterClickingPreviewIcon() {

        WriteToReport("=======Start of bf_VerifyAfterClickingPreviewIcon=============");


        WriteToReport("=======End of bf_VerifyAfterClickingPreviewIcon===============");
    }

}
