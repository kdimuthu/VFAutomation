package testcases.samples;

import org.testng.annotations.Test;
import pages.sample.SamplePage;
import utility.ExcelReader;
import utility.SeleniumTestBase;

public class Sample_Tests extends SeleniumTestBase {

   SamplePage SamplePage_;

    // Verify campaign creation
    @Test(priority = 1, enabled = true)
    public void tc_VerifyCampaign() throws InterruptedException {
        SamplePage_ = new SamplePage(driver);
        //Open the Self Care portal
        SamplePage_.bf_OpenApplication();
        //Login
        SamplePage_.bf_Login();
        //Create Campaign
        SamplePage_.bf_CreateCampaign();
    }
}