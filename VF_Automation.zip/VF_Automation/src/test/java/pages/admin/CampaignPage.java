package pages.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utility.TestBase_Commands;

public class CampaignPage extends TestBase_Commands {

    /** ================================= Left Menu In Campaign Page ====================================== **/
    private static By btn_Dashboard = By.xpath("");
    private static By btn_Campaigns = By.xpath("");
    private static By btn_QuestionBank = By.xpath("");
    private static By btn_Users = By.xpath("");
    private static By btn_Reports = By.xpath("");
    private static By btn_SystemSetting = By.xpath("");

    /** ================================= Grid In Campaign Page ====================================== **/
    private static By lbl_Campaigns = By.xpath("");
    private static By btn_CreateCampaign = By.xpath("");
    private static By tb_All = By.xpath("");
    private static By tb_Open =  By.xpath("");
    private static By tf_SearchForCampaigns = By.xpath("");
    private static By lbl_SearchByCampaigns = By.xpath("");
    private static By btn_Search = By.xpath("");
    private static By dd_Date = By.xpath("");
    private static By dd_Tags = By.xpath("");
    private static By dd_Status = By.xpath("");
    private static By btn_ListView = By.xpath("");
    private static By btn_CardView = By.xpath("");
    private static By itm_TopResultsCount = By.xpath("");
    private static By lbl_TopResults = By.xpath("");
    private static By lbl_PageInTop = By.xpath("");
    private static By tf_PageNumberInTop = By.xpath("");
    private static By lbl_OfInTop = By.xpath("");
    private static By itm_NumberOfPagesInTop = By.xpath("");
    private static By lbl_DisplayInTop = By.xpath("");
    private static By dd_RowCountInTop = By.xpath("");
    private static By lbl_PerPageInTop = By.xpath("");
    private static By btn_TopLeftNavigation = By.xpath("");
    private static By Btn_TopRightNavigation = By.xpath("");
    private static By lbl_CampaignName = By.xpath("");
    private static By btn_SortByCampaignName = By.xpath("");
    private static By lbl_StartDate = By.xpath("");
    private static By btn_SortByStartDate = By.xpath("");
    private static By lbl_EndDate = By.xpath("");
    private static By btn_SortByEndDate = By.xpath("");
    private static By lbl_Status = By.xpath("");
    private static By lbl_Action = By.xpath("");
    private static By lbl_FirstCampaignName = By.xpath("");
    private static By lbl_FirstCampaignStartDate = By.xpath("");
    private static By lbl_FirstCampaignEndDate = By.xpath("");
    private static By lbl_FirstCampaignStatus = By.xpath("");
    private static By btn_FirstCampaignView = By.xpath("");
    private static By btn_FirstCampaignEdit = By.xpath("");
    private static By btn_FirstCampaignMoreOptions = By.xpath("");
    private static By lbl_LastCampaignName = By.xpath("");
    private static By lbl_LastCampaignStartDate = By.xpath("");
    private static By lbl_LastCampaignEndDate = By.xpath("");
    private static By lbl_LastCampaignStatus = By.xpath("");
    private static By btn_LastCampaignView = By.xpath("");
    private static By btn_LastCampaignEdit = By.xpath("");
    private static By btn_LastCampaignMoreOptions = By.xpath("");
    private static By lbl_PageInBottom = By.xpath("");
    private static By tf_PageNumberInBottom = By.xpath("");
    private static By lbl_OfInBottom = By.xpath("");
    private static By itm_NumberOfPagesInBottom = By.xpath("");
    private static By lbl_DisplayInBottom = By.xpath("");
    private static By dd_RowCountInBottom = By.xpath("");
    private static By lbl_PerPageInBottom = By.xpath("");
    private static By btn_BottomLeftNavigation = By.xpath("");
    private static By Btn_BottomRightNavigation = By.xpath("");


    public CampaignPage(WebDriver driver) {
        this.driver = driver;
    }

    // Verify the campaign UI
    public void bf_VerifyCampaignsUI() {

        WriteToReport("=======Start of bf_VerifyCampaignsUI=============");


        WriteToReport("=======End of bf_VerifyCampaignsUI=============");
    }

    // Click on create campaign button
    public void bf_ClickCreateCampaign() {

        WriteToReport("=======Start of bf_ClickCreateCampaign=============");


        WriteToReport("=======End of bf_ClickCreateCampaign=============");
    }

    // Moving Tabs
    public void bf_MoveTabs() {

        WriteToReport("=======Start of bf_MoveTabs=============");


        WriteToReport("=======End of bf_MoveTabs=============");
    }

    // Verify All Tab UI
    public void bf_VerifyAllTabUI() {

        WriteToReport("=======Start of bf_VerifyAllTabUI=============");


        WriteToReport("=======End of bf_VerifyAllTabUI=============");
    }

    // Verify open tab UI
    public void bf_VerifyOpenTabUI() {

        WriteToReport("=======Start of bf_VerifyOpenTabUI=============");

        WriteToReport("=======End of bf_VerifyOpenTabUI=============");
    }

    // Click on list view or card view icon
    public void bf_ClickListViewOrCardView() {

        WriteToReport("=======Start of bf_ClickListViewOrCardView=============");

        WriteToReport("=======End of bf_ClickListViewOrCardView=============");
    }

    // Verify card view UI
    public void bf_VerifyCardViewUI() {

        WriteToReport("=======Start of bf_VerifyCardViewUI=============");

        WriteToReport("=======End of bf_VerifyCardViewUI=============");
    }

    // Verify list view UI
    public void bf_VerifyListViewUI() {

        WriteToReport("=======Start of bf_VerifyListViewUI=============");

        WriteToReport("=======End of bf_VerifyListViewUI=============");
    }

    // Verify page navigation
    public void bf_VerifyPageNavigation() {

        WriteToReport("=======Start of bf_VerifyPageNavigation=============");

        WriteToReport("=======End of bf_VerifyPageNavigation=============");
    }

    // Get campaign count
    public void bf_CampaignCount() {

        WriteToReport("=======Start of bf_CampaignCount=============");

        WriteToReport("=======End of bf_CampaignCount=============");
    }

    // Search using search for campaigns
    public void bf_SearchUsingSearchForCampaigns() {

        WriteToReport("=======Start of bf_SearchUsingSearchForCampaigns=============");

        WriteToReport("=======End of bf_SearchUsingSearchForCampaigns=============");
    }

    // Verify search results search using search for campaigns
    public void bf_VerifySearchResultsAfterSearchingSearchForCampaigns() {

        WriteToReport("=======Start of bf_VerifySearchResultsAfterSearchingSearchForCampaigns=============");

        WriteToReport("=======End of bf_VerifySearchResultsAfterSearchingSearchForCampaigns=============");
    }

    // Clear search for campaigns search field
    public void bf_ClearSearchForCampaignsSearchField() {

        WriteToReport("=======Start of bf_ClearSearchForCampaignsSearchField=============");

        WriteToReport("=======End of bf_ClearSearchForCampaignsSearchField=============");
    }

    // Filter using date filter
    public void bf_FilterUsingDateFilter() {

        WriteToReport("=======Start of bf_FilterUsingDateFilter=============");

        WriteToReport("=======End of bf_FilterUsingDateFilter=============");
    }

    // Verify search results after filtering from date filter
    public void bf_VerifySearchResultsAfterFilteringFromDateFilter() {

        WriteToReport("=======Start of bf_VerifySearchResultsAfterFilteringFromDateFilter=============");

        WriteToReport("=======End of bf_VerifySearchResultsAfterFilteringFromDateFilter=============");
    }

    // Filter using tag filter
    public void bf_FilterUsingTagsFilter() {

        WriteToReport("=======Start of bf_FilterUsingTagsFilter=============");

        WriteToReport("=======End of bf_FilterUsingTagsFilter=============");
    }

    // Verify search results after filtering from tags filter
    public void bf_VerifySearchResultsAfterFilteringFromTagsFilter() {

        WriteToReport("=======Start of bf_VerifySearchResultsAfterFilteringFromTagsFilter=============");

        WriteToReport("=======End of bf_VerifySearchResultsAfterFilteringFromTagsFilter=============");
    }

    // Filter using status filter
    public void bf_FilterUsingStatusFilter() {

        WriteToReport("=======Start of bf_FilterUsingStatusFilter=============");

        WriteToReport("=======End of bf_FilterUsingStatusFilter=============");
    }

    // Click on column label for sorting
    public void bf_ClickOnColumnLabelForSorting() {

        WriteToReport("=======Start of bf_ClickOnColumnLabelForSorting=============");

        WriteToReport("=======End of bf_ClickOnColumnLabelForSorting=============");
    }

    // Verify sorting after campaign name sort
    public void bf_VerifySortingAfterCampaignNameSort() {

        WriteToReport("=======Start of bf_VerifySortingAfterCampaignNameSort=============");

        WriteToReport("=======End of bf_VerifySortingAfterCampaignNameSort=============");
    }

    // Verify sorting after start date sort
    public void bf_VerifySortingAfterStartDateSort() {

        WriteToReport("=======Start of bf_VerifySortingAfterStartDateSort=============");

        WriteToReport("=======End of bf_VerifySortingAfterStartDateSort=============");
    }

    // Verify sorting after end date sort
    public void bf_VerifySortingAfterEndDateSort() {

        WriteToReport("=======Start of bf_VerifySortingAfterEndDateSort=============");

        WriteToReport("=======End of bf_VerifySortingAfterEndDateSort=============");
    }

    // Click item from left menu
    public void bf_ClickItemFromLeftMenu() {

        WriteToReport("=======Start of bf_ClickItemFromLeftMenu=============");

        WriteToReport("=======End of bf_ClickItemFromLeftMenu=============");
    }


}
