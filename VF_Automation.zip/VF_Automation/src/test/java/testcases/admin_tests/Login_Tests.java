package testcases.admin_tests;

import org.testng.annotations.Test;
import pages.admin.LoginPage;
import utility.ExcelReader;
import utility.SeleniumTestBase;

public class Login_Tests extends SeleniumTestBase {

    LoginPage _LoginPage;

    // Verify the login ui of admin portal
    @Test(priority = 1, enabled = true)
    public void tc_VerifyAdminPortalUI() {
        _LoginPage = new LoginPage(driver);
        //Open Application
        _LoginPage.bf_OpenApplication();
        //Verify Login UI
        _LoginPage.bf_VerifyLoginUI();

    }
}
